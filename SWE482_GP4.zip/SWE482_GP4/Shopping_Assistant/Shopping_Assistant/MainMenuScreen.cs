﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace Shopping_Assistant
{
    public partial class MainMenuScreen : Form
    {
        DataTable dt_locations = new DataTable();//creates a datatable to store the store location data
        Form previousForm;//create a variable to hold the previous form
        string userID = "";//variable used to store the users ID number
        string locationID = "";//variable used to store the location ID
        string address = "";//variable used to store the location address
        string city = "";//variable used to store the location city
        string state = "";//variable used to store the location state
        string zip = "";//variable used to store the location zip
        string county = "";//variable used to store the location county

        //this method is the constructor for the Main Menu Screen
        public MainMenuScreen(Form parentForm, string usersID)
        {
            if (dt_locations.Columns.Count == 0)// if there are no columns in the table
            {
                dt_locations.Columns.Add("locationID",typeof(string));//adds a column
                dt_locations.Columns.Add("address",typeof(string));//adds a column
                dt_locations.Columns.Add("city",typeof(string));//adds a column
                dt_locations.Columns.Add("state",typeof(string));//adds a column
                dt_locations.Columns.Add("zip",typeof(string));//adds a column
                dt_locations.Columns.Add("county", typeof(string));//adds a column
            }

            if (dt_locations.Rows.Count == 0)//if there are no rows in the table
            {
                ImportProductData(dt_locations, Shopping_Assistant.Properties.Resources.Store_Location_Data);//imports the store location data into the datatable
            }

            userID = usersID;//sets the userID variable to equal the user's ID
            previousForm = parentForm;//sets previousForm variable to equal the form that called this one
            InitializeComponent();//renders the Main Menu form
            dt_locations.DefaultView.Sort = ("county ASC");//sorts the data by county
            locationDropDownBox.DataSource = dt_locations;//makes the datatable the data source for the dropdown box
            locationDropDownBox.ValueMember = "locationID";//dictates the value column that will associate to the selected item
            locationDropDownBox.DisplayMember = "County";//dictates what column data will display in the textbox
            locationDropDownBox.SelectedIndex = 0;
        }

        private void signOutButton_Click(object sender, EventArgs e)//when the Sign Out button is clicked
        {
            previousForm.Show();//makes the previous form visible again
            this.Close();//closes this form
        }

        private void mainMenuScreen_Close(object sender, EventArgs e)//when the "X" buttion is used to close the form
        {
            previousForm.Show();//makes the previous form visible again
            //a close form call is not needed here as the form is already closing
        }

        private void eventsButton_Click(object sender, EventArgs e)//when the Sales Events button is clicked
        {
            Form EventsScreen = new EventsScreen(this,locationID.ToString());//creates a new instance of the Events screen
            EventsScreen.Show();//displays the new Events screen
            this.Hide();//Hides this form from view
        }

        private void couponButton_Click(object sender, EventArgs e)//when the Coupons button is clicked
        {
            Form CouponScreen = new CouponScreen(this, userID);//creates a new instance of the Coupons screen
            CouponScreen.Show();//displays the new Coupons screen
            this.Hide();//Hides this form from view
        }

        private void groceryListButton_Click(object sender, EventArgs e)//when the Shopping Lists button is clicked
        {
            Form ShoppingListScreen = new ShoppingListScreen(this, userID.ToString(), locationID.ToString());//creates a new instance of the Shopping List screen
            ShoppingListScreen.Show();//displays the new Shopping List screen
            this.Hide();//Hides this form from view
        }

        private void locationDropDownBox_ValueSelected(object sender, EventArgs e)// when the user selects a location from the dropdown box
        {
            for (var row = 0;row < dt_locations.Rows.Count; row++)//loops through the datatable to find matching location record
            {
                if (dt_locations.Rows[row]["locationID"].ToString() == locationDropDownBox.SelectedValue.ToString())// if the datatable row matches the location id from the dopdown list
                {
                    locationID = dt_locations.Rows[row]["locationID"].ToString();//populates variable based on selected location
                    address = dt_locations.Rows[row]["address"].ToString();//populates variable based on selected location
                    city = dt_locations.Rows[row]["city"].ToString();//populates variable based on selected location
                    state = dt_locations.Rows[row]["state"].ToString();//populates variable based on selected location
                    zip = dt_locations.Rows[row]["zip"].ToString();//populates variable based on selected location
                    county = dt_locations.Rows[row]["county"].ToString();//populates variable based on selected location

                    locationDetailsLabel.Text = address.ToString() + ", " + city.ToString() + " " + state.ToString() + " " + zip.ToString();// populates the location details label
                }
            }
        }

        static void ImportProductData(DataTable dataTable, string fileData)//this method is used to import data from a csv file and place it into a datatable object
        {
            //Load File into DatatTable
            //reads entire txt file
            string wholeFile = fileData;

            //breaks file into each distinct row (This will add a blank row for each row since it is looking at returns and new lines)
            string[] fileRows = wholeFile.Split("\r\n".ToArray());

            //This loop add the data to the datatable while ignoring any empty or blank lines.
            foreach (string r in fileRows)
            {
                if (r != "")
                {
                    string[] fileRowFields = r.Split(",".ToCharArray());//splits the string into multiple fields
                    dataTable.Rows.Add(fileRowFields);//adds the new fields to a datatable
                }
            }
        }

    }
}
