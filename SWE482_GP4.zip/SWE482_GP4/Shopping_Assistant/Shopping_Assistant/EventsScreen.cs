﻿using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Shopping_Assistant
{
    public partial class EventsScreen : Form
    {
        Form previousForm;//variable used to store the previous screen
        DataTable dt_eventData = new DataTable();//creates a table to store sales event data
        string locationID = "";//creates a variable to store the locaiton ID

        //this method is the constructor for the SalesEvents screen
        public EventsScreen(Form parentForm, string locationsID)
        {
            locationID = locationsID.ToString();//populates the variable storing the locaitons ID

            string eventDataFilePath = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName + "\\non-embedded text files\\Sales Events\\" + locationID.ToString() + "-Event_Data.csv";// creates a variable to stare the file path for the data

            dt_eventData.Clear();//clears the datatable to prepair for import

            if (dt_eventData.Columns.Count == 0)// if there are no columns in the datatable
            {
                dt_eventData.Columns.Add("Product Name", typeof(string));//adds a column
                dt_eventData.Columns.Add("Discount %", typeof(string));//adds a column
                dt_eventData.Columns.Add("Start Date", typeof(string));//adds a column
                dt_eventData.Columns.Add("End Date", typeof(string));//adds a column
            }

            if (dt_eventData.Rows.Count == 0)//if there are no rows in the datatable
            {
                ImportData(dt_eventData, eventDataFilePath);//imports the data from the file into the datatable
            }

            previousForm = parentForm;//sets the previousForm variable to equal the last screen
            InitializeComponent();//renders the Events screen

            dt_eventData.DefaultView.Sort = ("Product Name ASC");//sorts the datatable by name
            SaleDetailsGridView.DataSource = dt_eventData;//sets the gridview's datasource to the datatable
            SaleDetailsGridView.Refresh();//refreshes the datagrid
        }

        private void backButton_Click(object sender, EventArgs e)//when the Back button is clicked
        {
            previousForm.Show();//makes the previous screen visible again
            this.Close();//closes this screen
        }
        
        private void EventScreen_Close(object sender, EventArgs e)//when the screen is closing via the "X" button
        {
            previousForm.Show();//makes the previous screen visible again
            //a close form call is not needed here as the screen is already closing
        }

        static void ImportData(DataTable datatable, string filePath)// this method imports a text/csv file and pushes it into a datatable object
        {
            //Load File into DatatTable
            using (StreamReader inFile = new StreamReader(filePath))//this creates a streamreader to read the contents of the text file
            {
                //reads entire txt file
                string wholeFile = inFile.ReadToEnd();

                //breaks file into each distinct row (This will add a blank row for each row since it is looking at returns and new lines)
                string[] fileRows = wholeFile.Split("\r\n".ToArray());

                //This loop add the data to the datatable while ignoring any empty or blank lines.
                foreach (string r in fileRows)
                {
                    if (r != "")
                    {
                        string[] fileRowFields = r.Split(",".ToCharArray());//this splits each line from the text file into individual fields
                        datatable.Rows.Add(fileRowFields);//this will add each newly created row of data to the datatable
                    }
                }
            }
        }
    }
}
